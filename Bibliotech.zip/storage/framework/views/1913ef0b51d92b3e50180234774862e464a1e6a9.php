<?php if(count($loans)): ?>
<?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$oldDate = $loan->date;
$newDate = new DateTime($oldDate);
if($loan->type == 'Profesor'){
$newDate->add(new DateInterval('P14D')); // P1D means a period of 1 day
$tarifa = 20;
}
if($loan->type == 'Alumno'){
$newDate->add(new DateInterval('P7D')); // P1D means a period of 1 day
$tarifa = 10;
}
$fomattedDate = $newDate->format('Y-m-d');

$fechaActual = date('d-m-Y');

$inicio = strtotime($fomattedDate);
$hoy = strtotime($fechaActual);
$dias = $hoy-$inicio;
?>
<tr>
<td class="text-center"><h5><?php echo e($loan->code_user); ?></h5></td>
<td class="text-center"><h5><?php echo e($loan->id_book); ?></h5></td>
<td class="text-center"><h5><?php echo e($loan->date); ?></h5></td>
<td class="text-center"><h5><?php echo e($fomattedDate); ?></h5></td>
<td class="text-center"><h5><?php echo e($loan->type); ?></h5></td>


<td class="text-center"><h5>
  <div class="col d-grid gap-2">
<?php switch($loan->status):
  case (1): ?>
  <a href="<?php echo e(route('loan_end', $loan->id)); ?>" style="font-size: 4rem" type="submit" class="btn btn-success btn-lg"><h5>ENTREGADO</h5></a>
      <?php break; ?>
  <?php case (2): ?>
  <a href="<?php echo e(route('multa', $loan->id)); ?>" style="font-size: 4rem" type="submit" class="btn btn-danger btn-lg"><h5>MULTA</h5></a>
  <br>
  <a href="<?php echo e(route('loan_end', $loan->id)); ?>" style="font-size: 4rem" type="submit" class="btn btn-success btn-lg"><h5>ENTREGADO</h5></a>
      <?php break; ?>
  <?php case (3): ?>
      CONCLUIDO
      <?php break; ?>
  <?php case (4): ?>
  <h5>PAGADO</h5>
  <a href="<?php echo e(route('loan_end', $loan->id)); ?>" style="font-size: 4rem" type="submit" class="btn btn-success btn-lg"><h5>ENTREGADO</h5></a>
  <?php break; ?>
  <?php default: ?>
      
<?php endswitch; ?>  
  </div>
</h5></td>

  
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\Users\emaes\Desktop\Universidad\SEMESTRE 4\PROGRAMACION INTERNET\biblio\biblio\resources\views/loans/pages.blade.php ENDPATH**/ ?>