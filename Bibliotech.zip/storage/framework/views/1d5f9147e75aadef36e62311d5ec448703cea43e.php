<?php if(count($books)): ?>
<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td class="text-center"><h5><a <?php if(DB::table('loans')->where('id_book', $book->isbn)->where('status', '!=', '3')->first()): ?> style="color: rgb(200, 7, 28);" <?php else: ?> href="<?php echo e(route('book_loans', $book->isbn)); ?>" style="color: rgb(0, 170, 28);" <?php endif; ?> class="text-decoration-none"><b><?php echo e($book->isbn); ?></b></a></h5></td>
  <td class="text-center"><h5><?php echo e($book->title); ?></h5></td>
  <td class="text-center"><h5><?php echo e($book->author); ?></h5></td>

<td class="text-center"><h5><?php echo e($book->editorial); ?></h5></td>
<td class="text-center"><h5><?php echo e($book->year_of_publication); ?></h5></td>
<td class="text-center"><h5><?php echo e($book->issue_number); ?></h5></td>
<td class="text-center"><h5><?php echo e($book->edition); ?></h5></td>

  
  <td class="text-center"><div class="d-grid gap-2"><button class="btn btn-warning" type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($book->isbn); ?>"><h5><i class="fas fa-times"></i></h5></button></div></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="exampleModal<?php echo e($book->isbn); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-xl">
  <div class="modal-content">
    <div class="modal-body">
      <h5>Seguro de eliminar el libro con isbn: <?php echo e($book->isbn); ?></h5>
    </div>
<div class="container-fluid">
  <div class="row">
    <div class="col d-grid gap-2">
    <button type="button" class="btn btn-secondary btn-lg" data-bs-dismiss="modal">Cerrar</button>
    </div>
    <div class="col d-grid gap-2">
    <a href="<?php echo e(route('book_delete', $book->isbn)); ?>" class="btn btn-info btn-lg">Eliminar</a>
    </div>
  </div>
</div>
<br>
  </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?><?php /**PATH C:\Users\emaes\Desktop\Universidad\SEMESTRE 4\PROGRAMACION INTERNET\biblio\biblio\resources\views/books/pages.blade.php ENDPATH**/ ?>