<?php if(count($users)): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><h5><a style="color: black;" class="text-decoration-none" href="<?php echo e(route('viewuser', $user->id)); ?>"><b><?php echo e($user->code); ?></b></a></h5></td>
        <td class="text-center">
          <?php if($user->img == "img.png"): ?>
        <img class="shadow" style="width: 100px;" src="<?php echo e(asset('img.png')); ?>" alt="">
            
        <?php else: ?>
        <img class="shadow" style="width: 100px;" src="<?php echo e(url('getfile/' .$user->img )); ?>" alt="">
        <?php endif; ?>
       </td>
        <td class="text-center"><h5><?php echo e($user->name); ?></h5></td>
        <td class="text-center"><h5><?php echo e($user->lastname); ?></h5></td>
        <td class="text-center"><h5><?php echo e($user->type); ?></h5></td>

      <td class="text-center"><h5><?php echo e($user->degree); ?></h5></td>
      <td class="text-center"><h5><?php echo e($user->phone); ?></h5></td>

        <td class="text-center"><div class="d-grid gap-2"><a href="<?php echo e(route('edituser', $user->id)); ?>" class="btn btn-secondary"><h5><i class="fas fa-edit"></i></h5></a></div></td>
        <td class="text-center"><div class="d-grid gap-2"><button class="btn btn-warning" type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($user->id); ?>"><h5><i class="fas fa-times"></i></h5></button></div></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="exampleModal<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog modal-xl">
       <div class="modal-content">
         <div class="modal-body">
           <h5>Seguro de eliminar el usuario con codigo: <?php echo e($user->code); ?></h5>
         </div>
     <div class="container-fluid">
       <div class="row">
         <div class="col d-grid gap-2">
         <button type="button" class="btn btn-secondary btn-lg" data-bs-dismiss="modal">Cerrar</button>
         </div>
         <div class="col d-grid gap-2">
         <a href="<?php echo e(route('user_delete', $user->id)); ?>" class="btn btn-info btn-lg">Eliminar</a>
         </div>
       </div>
     </div>
     <br>
       </div>
     </div>
   </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php endif; ?><?php /**PATH C:\Users\emaes\Desktop\Universidad\SEMESTRE 4\PROGRAMACION INTERNET\biblio\biblio\resources\views/users/pages.blade.php ENDPATH**/ ?>